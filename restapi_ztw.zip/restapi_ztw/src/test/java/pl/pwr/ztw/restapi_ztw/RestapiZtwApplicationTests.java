package pl.pwr.ztw.restapi_ztw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiZtwApplicationTests {

	@Test
	void contextLoads() {
	}

}
